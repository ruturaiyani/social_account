<?php
include("config.php");
include("head.php");
?>
<?php
$sql="select * from tbl_user_details";
			$result = mysqli_query($con, $sql);
			


if(isset($_REQUEST['del']))
		{
			mysqli_query($con,"delete from tbl_user_details where user_id=".$_REQUEST['del']);
			?>
                <script type="text/javascript">
                window.location.href="view_user.php";
                </script>
        
<script type="text/javascript">
window.location.href="view_user.php";
</script>	
		
<?php		
}
?>
<h2><center><br />View user </center></h2><br />
<div style="overflow-x:auto;">
  <table>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>phone no</th>
      <th>gender</th>
      <th>hobby</th>
      <th>Date Of Birth</th>
      <th>photo</th>
      <th>Address</th>
      <th>city</th>
      <th>zipcode</th>
      <th>accounttype</th>
      <th>Edit</th>
      <th>Delete</th>
      
    </tr>
  
  <?php 
			//$select=mysqli_query("select * from tbl_user_details");
			
			$sql="select * from tbl_user_details";
			$result = mysqli_query($con, $sql);
			
			
			while($row=mysqli_fetch_assoc($result))
			{
		?>
		<tr>
            
            
			<td><?php echo $row['user_name']; ?></td>
            <td><?php echo $row['user_email_id']; ?></td>
            <td><?php echo $row['user_phone']; ?></td>
            
            <td><?php echo $row['user_gender']; ?></td>
            <td><?php echo $row['user_hobby']; ?></td>
            <td><?php echo $row['user_dob']; ?></td>
            <td><?php echo $row['user_photo']; ?></td>
            <td><?php echo $row['user_address']; ?></td>
            <td><?php echo $row['user_city']; ?></td>
            <td><?php echo $row['user_zipcode']; ?></td>
           <td><?php echo $row['user_ac_type']; ?></td>
          
			<?php  echo"<td align='center'><a href='edit_user.php?epid=$row[user_id]'>"; ?>
    <img src="images/edit.png"  />
    <?php	  echo"<td align='center'><a href='view_user.php?del=$row[user_id]'>"; ?>
    <img src="images/delete.png"  />
   	<?php
			}
		?>	
		
    
 </table>
 </div>
 

<?php
include("footer.php");
?>
