<div class="footer"><center>DEVELOPED BY : RAIYANI RUTU</center><img src="images/footer.jpg" style="background:url(images/footer.jpg) no-repeat; width:100%;" /></div>
</body>
</html>
