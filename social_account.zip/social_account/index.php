<?php
include("config.php");
include("head.php");
error_reporting(0);
?>

<h2><center><br />Add User</center></h2><br />

<form enctype="multipart/form-data" method="post" name="form1">
  <div class="imgcontainer">
    
  </div>

  <div class="container">
    <label><b>Name</b></label>
    <input type="text" placeholder="Enter name" name="name" onblur="name_onblur()"  required><br />
    
	<label><b>Email</b></label>
    <input type="email" placeholder="Enter Email" name="email" required><br />
    
    <label><b>Contact Number</b></label>
    <input type="text" placeholder="Enter Contact Number" name="phone" required><br />
    
    <label><b>password</b></label>
    <input type="password" placeholder="Enter password" name="password" required><br />
    
    <label><b>Gender</b></label><br />
      <input type="radio" class="radio1" name="gender" value="Female">Female<br />
      <input type="radio" name="gender" class="radio1" value="Male">Male<br />
    </label><br />
   
    <label><b>Hobby</b></label>
<input type="text" placeholder="Enter hobby" name="hobby" required><br />
    
    <label><b>Date Of Birth</b></label>
<input type="text" name="txt_cal" id="cal">

	<label><b>Photo</b></label>
   <input type="file" name="pic_path" required><br />
      
    
    <label><b>Address</b></label>
    <textarea name="address" placeholder="Enter Adddress"></textarea><br />
    
    <label><b>City</b></label>
    <input type="text" placeholder="Enter city" name="city" required /><br />
    
    <label><b>Zipcode</b></label>
    <input type="text" placeholder="Enter zipcode" name="zipcode" required /><br />
    
    
     <label><b>Account type</b></label>
    <select name="actype">
	<option value="PUBLIC">PUBLIC</option>
    <option value="PRIVATE">PRIVATE</option>
    <option value="BUSINESS">BUSINESS</option>
    </select>
   
    
    <input type="submit" name="add_account" onclick="butCheckForm_onclick()" value="Submit">

</form></div>
  <?php
$count=0;
if(isset($_REQUEST["add_account"]))
{	
	$nm=$_REQUEST["name"];
	$em=$_REQUEST["email"];
	$ph=$_REQUEST["phone"];
	$pwd=$_REQUEST["password"];
	$g=$_REQUEST["gender"];
	$hob=$_REQUEST["hobby"];
	$dob=$_REQUEST["txt_cal"];
	
	$file=$_FILES['pic_path']['name'];
	$dest="images/$file";
	$src=$_FILES['pic_path']['tmp_name'];
	move_uploaded_file($src,$dest);
	$a=$_REQUEST["address"];
	$cit=$_REQUEST["city"];
	$zip=$_REQUEST["zipcode"];
	$act=$_REQUEST["actype"];
	
	$sql="insert into tbl_user_details values('','$nm','$em','$ph','$pwd','$g','$hob','$dob','$file','$a','$cit','$zip','$act','1')";
			if ($count==0) {
			mysqli_query($con, $sql);
    echo "<script> alert('Add User Details Successfully.')</script>";
} else {
    echo "Error: " . $sql . "<br>" . $con->error;
}
$con->close();
		
    }
						?> 
						
<?php
include("footer.php");
?>