<?php
include("config.php");
include("head.php");
error_reporting(0);
$sql="select * from tbl_user_details where user_id=".$_REQUEST["epid"];
			$result = mysqli_query($con, $sql);
			$row=mysqli_fetch_assoc($result);
?>
<h2><center><br />edit User</center></h2><br />

<form enctype="multipart/form-data" method="post">
  <div class="imgcontainer">
    
  </div>

  <div class="container">
    <label><b>Name</b></label>
    <input type="text" placeholder="Enter name" name="name" value="<?php echo $row['user_name']; ?>" required><br />
    
	<label><b>Email</b></label>
    <input type="email" placeholder="Enter Email" value="<?php echo $row['user_email_id']; ?>" name="email" required><br />
    
    <label><b>Contact Number</b></label>
    <input type="text" placeholder="Enter Contact Number" name="phone" value="<?php echo $row['user_phone']; ?>" required><br />
   
    
    <label><b>Gender</b></label><br />
    <?php
	if($row["user_gender"]=="Female")
	  {
	  ?>
      <input type="radio" class="radio1" name="gender" checked="checked" value="Female">Female<br />
      <input type="radio" name="gender" class="radio1" value="Male">Male<br />
      <?php
	  }
	  if($row["user_gender"]=="Male")
	  {
	  ?>
      <input type="radio" class="radio1" name="gender"  value="Female">Female<br />
      <input type="radio" name="gender" class="radio1" checked="checked" value="Male">Male<br />
      <?php
	  }
	  ?>
    </label><br />
   
    <label><b>Hobby</b></label>
<input type="text" placeholder="Enter hobby" value="<?php echo $row['user_hobby']; ?>" name="hobby" required><br />
    
    <label><b>Date Of Birth</b></label>
<input type="text" name="txt_cal" id="cal" value="<?php echo $row['user_dob']; ?>">

	<label><b>Photo</b></label>
       <input type="file" name="pic_path" required><br />
<img src="images/<?php echo $row['user_photo']; ?>" height="150px" width="150px" style="margin-left:20%;"/>
      
    
    <label><b>Address</b></label>
    <textarea name="address" placeholder="Enter Adddress"><?php echo $row['user_address']; ?></textarea><br />
    
    <label><b>City</b></label>
    <input type="text" placeholder="Enter city" name="city" value="<?php echo $row['user_city']; ?>" required /><br />
    
    <label><b>Zipcode</b></label>
    <input type="text" placeholder="Enter zipcode" value="<?php echo $row['user_zipcode']; ?>" name="zipcode" required /><br />
    
    
     <label><b>Account type</b></label>
    <select name="actype">
    <?php
    if($row["user_ac_type"]=="PUBLIC")
	{
	?>
	<option value="PUBLIC" selected="selected">PUBLIC</option>
    <option value="PRIVATE">PRIVATE</option>
    <option value="BUSINESS">BUSINESS</option>
    <?php
	}
	if($row["user_ac_type"]=="PRIVATE")
	{
	?>
	<option value="PUBLIC">PUBLIC</option>
    <option value="PRIVATE" selected="selected">PRIVATE</option>
    <option value="BUSINESS">BUSINESS</option>
    <?php
	}
	if($row["user_ac_type"]=="BUSINESS")
	{
	?>
	<option value="PUBLIC">PUBLIC</option>
    <option value="PRIVATE">PRIVATE</option>
    <option value="BUSINESS" selected="selected">BUSINESS</option>
    <?php
	}
	?>
    </select>
   
    
    <input type="submit" name="add_account"  value="Submit">

</form></div>
  <?php
$count=0;
if(isset($_REQUEST["add_account"]))
{	
	$i=$_REQUEST['epid'];
	$nm=$_REQUEST["name"];
	$em=$_REQUEST["email"];
	$ph=$_REQUEST["phone"];
	$pwd=$_REQUEST["password"];
	$g=$_REQUEST["gender"];
	$hob=$_REQUEST["hobby"];
	$dob=$_REQUEST["txt_cal"];
	
	$file=$_FILES['pic_path']['name'];
	
	if($file=="")
	{
	$temp=$_FILES['pic_path']['name'];
	$dest="images/$file";
	$src=$_FILES['pic_path']['tmp_name'];
	move_uploaded_file($src,$dest);
	}
	if($file!="")
	{
	$temp=$row["user_photo"];
	}
	
	
	$a=$_REQUEST["address"];
	$cit=$_REQUEST["city"];
	$zip=$_REQUEST["zipcode"];
	$act=$_REQUEST["actype"];
	
	mysqli_query($con,"UPDATE `tbl_user_details` SET user_name = '$nm' , user_email_id = '$em', user_phone = '$ph',user_gender = '$g', user_hobby = '$hob', user_dob = '$dob', user_photo = '$file', user_address = '$a', user_city = '$cit', user_zipcode = '$zip', user_ac_type ='$act'  WHERE user_id = '$i'");

?>
                <script type="text/javascript">
                window.location.href="view_user.php";
                </script>
        <?php	
}

?> 					
<?php
include("footer.php");
?>