<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link type="text/css" href="style.css" rel="stylesheet" />
<meta http-equiv="Content-Type" content="width=device-width, initial-scale=1" content="text/html; charset=utf-8" />
<script src="js/jquery.min.js"></script>
<script src="js/jquery-1.10.2.js"></script>
<script src="js/mjquery-ui.js"></script>
<script type="text/javascript" src="js/jquery.ptTimeSelect.js"></script>
<link rel="stylesheet" href="mjquery-ui.css">

<link rel="stylesheet" type="text/css" href="jquery.ptTimeSelect.css" />
<script type="text/javascript">
$(document).ready(function(){
	
	$('#cal').datepicker({ dateFormat: "yy-mm-dd" });

	
  	});			
 </script>
<title>User Detail</title>
</head>
<body>
<div class="head">
<a href="index.php" class="aa" >Add User</a>
<a href="view_user.php" class="aa1">View User</a>
</div>
</body>
</html>